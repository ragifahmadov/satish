<?php
// Verilənlər bazasına qoşulur, baza və cədvəllər yoxdursa avtomatik yaradır.

function get_pdo() {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $cfg = require __DIR__ . '/config.php';

    // Əvvəlcə serverə (bazasız) qoşuluruq ki, baza yoxdursa yarada bilək.
    $dsnServer = "mysql:host={$cfg['host']};port={$cfg['port']};charset={$cfg['charset']}";
    $tmp = new PDO($dsnServer, $cfg['user'], $cfg['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    $dbname = $cfg['dbname'];
    $tmp->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

    $dsn = "mysql:host={$cfg['host']};port={$cfg['port']};dbname={$dbname};charset={$cfg['charset']}";
    $pdo = new PDO($dsn, $cfg['user'], $cfg['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    ensure_schema($pdo);
    return $pdo;
}

function ensure_schema($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS salespeople (
        id CHAR(36) PRIMARY KEY,
        kod VARCHAR(50),
        soyad VARCHAR(100),
        ad VARCHAR(100),
        ataAdi VARCHAR(100),
        mobil JSON,
        qeyd TEXT,
        createdAt DATETIME
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS collectors (
        id CHAR(36) PRIMARY KEY,
        kod VARCHAR(50),
        soyad VARCHAR(100),
        ad VARCHAR(100),
        ataAdi VARCHAR(100),
        mobil JSON,
        qeyd TEXT,
        createdAt DATETIME
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS customers (
        id CHAR(36) PRIMARY KEY,
        soyad VARCHAR(100),
        ad VARCHAR(100),
        ataAdi VARCHAR(100),
        dogumTarixi DATE NULL,
        cinsiyet VARCHAR(20),
        vesiqeSeriya VARCHAR(10),
        vesiqeNomre VARCHAR(20),
        finKod VARCHAR(20),
        seher VARCHAR(100),
        rayon VARCHAR(100),
        kuce VARCHAR(150),
        bina VARCHAR(20),
        menzil VARCHAR(10),
        mobil JSON,
        qeyd TEXT,
        createdAt DATETIME
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS contracts (
        id CHAR(36) PRIMARY KEY,
        nomre VARCHAR(50),
        tarix DATE NULL,
        customerId CHAR(36),
        salespersonId CHAR(36),
        meblag DECIMAL(12,2),
        muddet INT,
        qeyd TEXT,
        tehsilatciTeyinatlari JSON,
        createdAt DATETIME,
        INDEX idx_customer (customerId),
        INDEX idx_salesperson (salespersonId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS payments (
        id CHAR(36) PRIMARY KEY,
        contractId CHAR(36),
        meblag DECIMAL(12,2),
        odemeTarixi DATE NULL,
        collectorId CHAR(36),
        qeyd TEXT,
        qrafikAyIndex INT,
        qrafikAyLabel VARCHAR(100),
        createdAt DATETIME,
        INDEX idx_contract (contractId),
        INDEX idx_collector (collectorId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
