<?php
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/db.php';
require __DIR__ . '/functions.php';

$col = isset($_GET['col']) ? $_GET['col'] : '';
$id  = isset($_GET['id']) ? $_GET['id'] : null;
$method = $_SERVER['REQUEST_METHOD'];

if (!isset($SCHEMA[$col])) {
    fail(404, 'Naməlum bölmə: ' . $col);
}
$schema = $SCHEMA[$col];

try {
    $pdo = get_pdo();
} catch (Exception $e) {
    fail(500, 'Verilənlər bazasına qoşulma xətası: ' . $e->getMessage() . '. config.php faylındaki məlumatları yoxlayın və MySQL-in işlək olduğuna əmin olun.');
}

try {
    switch ($method) {

        case 'GET':
            $stmt = $pdo->query("SELECT * FROM `$col` ORDER BY createdAt ASC");
            $out = [];
            foreach ($stmt->fetchAll() as $row) {
                $out[] = row_out($row, $schema);
            }
            echo json_encode($out);
            break;

        case 'POST':
            $body = json_decode(file_get_contents('php://input'), true);
            if (!is_array($body)) { $body = []; }
            $newId = make_uuid();
            $now = date('Y-m-d H:i:s');
            $cols = ['id', 'createdAt'];
            $placeholders = [':id', ':createdAt'];
            $params = [':id' => $newId, ':createdAt' => $now];
            foreach ($schema as [$name, $type]) {
                $cols[] = "`$name`";
                $placeholders[] = ":$name";
                $params[":$name"] = cast_in($body[$name] ?? null, $type);
            }
            $sql = "INSERT INTO `$col` (" . implode(',', $cols) . ") VALUES (" . implode(',', $placeholders) . ")";
            $pdo->prepare($sql)->execute($params);

            $sel = $pdo->prepare("SELECT * FROM `$col` WHERE id = :id");
            $sel->execute([':id' => $newId]);
            echo json_encode(row_out($sel->fetch(), $schema));
            break;

        case 'PUT':
            if (!$id) { fail(400, 'id parametri lazımdır'); }
            $body = json_decode(file_get_contents('php://input'), true);
            if (!is_array($body)) { $body = []; }
            $sets = [];
            $params = [':id' => $id];
            foreach ($schema as [$name, $type]) {
                if (array_key_exists($name, $body)) {
                    $sets[] = "`$name` = :$name";
                    $params[":$name"] = cast_in($body[$name], $type);
                }
            }
            if (!empty($sets)) {
                $sql = "UPDATE `$col` SET " . implode(',', $sets) . " WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                if ($stmt->rowCount() === 0) {
                    // ya heç nə dəyişmədi, ya da qeyd yoxdur -- yoxlayaq
                    $check = $pdo->prepare("SELECT id FROM `$col` WHERE id = :id");
                    $check->execute([':id' => $id]);
                    if (!$check->fetch()) { fail(404, 'Qeyd tapılmadı'); }
                }
            }
            $sel = $pdo->prepare("SELECT * FROM `$col` WHERE id = :id");
            $sel->execute([':id' => $id]);
            $row = $sel->fetch();
            if (!$row) { fail(404, 'Qeyd tapılmadı'); }
            echo json_encode(row_out($row, $schema));
            break;

        case 'DELETE':
            if (!$id) { fail(400, 'id parametri lazımdır'); }
            $pdo->prepare("DELETE FROM `$col` WHERE id = :id")->execute([':id' => $id]);
            echo json_encode(['ok' => true]);
            break;

        default:
            fail(405, 'Bu metod dəstəklənmir');
    }
} catch (PDOException $e) {
    fail(500, 'Verilənlər bazası xətası: ' . $e->getMessage());
}
