const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'data.json');

const COLLECTIONS = ['salespeople', 'collectors', 'customers', 'contracts', 'payments'];

function ensureDataFile() {
  if (!fs.existsSync(path.dirname(DATA_FILE))) {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  }
  if (!fs.existsSync(DATA_FILE)) {
    const empty = {};
    COLLECTIONS.forEach((c) => (empty[c] = []));
    fs.writeFileSync(DATA_FILE, JSON.stringify(empty, null, 2));
  }
}

function loadData() {
  ensureDataFile();
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function saveData(data) {
  // Yazmadan əvvəl köhnə faylın ehtiyat nüsxəsini saxla
  if (fs.existsSync(DATA_FILE)) {
    fs.copyFileSync(DATA_FILE, DATA_FILE + '.bak');
  }
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function checkCollection(req, res, next) {
  if (!COLLECTIONS.includes(req.params.col)) {
    return res.status(404).json({ error: 'Naməlum bölmə: ' + req.params.col });
  }
  next();
}

app.get('/api/:col', checkCollection, (req, res) => {
  const data = loadData();
  res.json(data[req.params.col]);
});

app.post('/api/:col', checkCollection, (req, res) => {
  const data = loadData();
  const item = { ...req.body, id: crypto.randomUUID(), createdAt: new Date().toISOString() };
  data[req.params.col].push(item);
  saveData(data);
  res.json(item);
});

app.put('/api/:col/:id', checkCollection, (req, res) => {
  const data = loadData();
  const list = data[req.params.col];
  const idx = list.findIndex((x) => x.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Qeyd tapılmadı' });
  list[idx] = { ...list[idx], ...req.body, id: req.params.id };
  saveData(data);
  res.json(list[idx]);
});

app.delete('/api/:col/:id', checkCollection, (req, res) => {
  const data = loadData();
  data[req.params.col] = data[req.params.col].filter((x) => x.id !== req.params.id);
  saveData(data);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log('Server işə düşdü: http://localhost:' + PORT);
  console.log('Məlumatlar bu fayla yazılır: ' + DATA_FILE);
});
