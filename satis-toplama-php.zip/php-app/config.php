<?php
// MySQL bağlantı tənzimləmələri.
// XAMPP-da default olaraq: istifadəçi=root, şifrə=boş.
// Başqa hostinqdə isə cPanel-in verdiyi məlumatları buraya yazın.
return [
    'host'    => '127.0.0.1',
    'port'    => '3306',
    'dbname'  => 'satis_toplama',
    'user'    => 'root',
    'pass'    => '',
    'charset' => 'utf8mb4',
];
