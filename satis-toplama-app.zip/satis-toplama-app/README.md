# Satış və Toplama İdarəetmə Sistemi

Bu, öz serverinizdə işə salına bilən müstəqil veb tətbiqdir. Ayrıca xarici xidmətə
ehtiyac yoxdur — bütün məlumatlar serverin öz üzərində, `data/data.json` faylında saxlanılır.

## Tələblər

- Server (VPS, şirkət daxili kompüter və s.) — Linux, Windows və ya macOS ola bilər
- Node.js 18 və ya daha yeni versiya quraşdırılmış olmalıdır
  (yoxlamaq üçün: `node -v`)

## Quraşdırma

1. Bu qovluğu (`satis-toplama-app`) serverə köçürün (zip-i açın).
2. Terminalda qovluğa keçin:
   ```
   cd satis-toplama-app
   ```
3. Asılılıqları yükləyin (internetə çıxış lazımdır, bir dəfəlik):
   ```
   npm install
   ```
4. Serveri işə salın:
   ```
   npm start
   ```
5. Brauzerdə açın: `http://SERVER_IP:3000` (öz kompüterinizdə sınaq üçün: `http://localhost:3000`)

Fərqli port istəsəniz:
```
PORT=8080 npm start
```

## Serveri daimi işlək saxlamaq

Terminalı bağlayanda server da dayanır. Daimi iş üçün `pm2` kimi bir alət tövsiyə olunur:

```
npm install -g pm2
pm2 start server.js --name satis-sistemi
pm2 save
pm2 startup
```

Bu, server yenidən başladıqda da tətbiqin avtomatik qalxmasını təmin edir.

## İnternetdən əlçatan etmək (domenlə açmaq)

Tətbiq default olaraq şifrəsiz (http) və giriş yoxlaması olmadan işləyir — ona görə
onu birbaşa internetə açmaq TÖVSİYƏ OLUNMUR. Əvəzində:

- Server yalnız şirkət daxili şəbəkədə (VPN və ya lokal şəbəkə) əlçatan olsun, YA DA
- `nginx` və ya `caddy` ilə tərsinə proksi (reverse proxy) qurub, üzərinə HTTPS (SSL
  sertifikatı) və əsas HTTP autentifikasiyası (basic auth) əlavə edin.

Bu addımlar üçün əlavə kömək istəsəniz, deyin — nginx konfiqurasiyasını da hazırlaya bilərəm.

## Ehtiyat nüsxə (backup)

Bütün məlumat `data/data.json` faylındadır. Hər yazılışdan əvvəl avtomatik olaraq
`data/data.json.bak` faylına ehtiyat nüsxə saxlanılır. Buna əlavə olaraq, bu faylı
mütəmadi (məs. hər gün) başqa yerə köçürməyi tövsiyə edirəm — məsələn cron tapşırığı ilə:

```
0 2 * * * cp /path/to/satis-toplama-app/data/data.json /path/to/backup/data-$(date +%F).json
```

## Neçə nəfər eyni vaxtda istifadə edə bilər?

Server açıq olan hər kompüterdən brauzerlə daxil olmaq mümkündür (məs. `http://server-ip:3000`).
Bütün istifadəçilər eyni məlumatı görür, dəyişikliklər 6 saniyəyə qədər gecikmə ilə
digər açıq pəncərələrdə də görünür (avtomatik yenilənmə).

## Struktur

```
satis-toplama-app/
  server.js       — API server (Node.js/Express)
  package.json    — asılılıqlar
  public/
    index.html    — bütün interfeys (HTML+CSS+JS, tək fayl)
  data/
    data.json     — bütün məlumatlar (avtomatik yaranır)
```
